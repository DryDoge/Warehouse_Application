create function kontrola_mnozstvo()
  returns trigger
language plpgsql
as $$
BEGIN
    IF ((NEW.mnozstvo < 0)) THEN
      RAISE EXCEPTION 'Zly pocet';
    END IF;
    RETURN NEW;
  END;
$$;

