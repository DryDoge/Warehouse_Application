create view neochutene_napoje as
  SELECT napoj.idnap,
    napoj.prichut,
    napoj.cena,
    napoj.druh,
    napoj.znacka,
    napoj.spotreba
   FROM napoj
  WHERE (napoj.prichut IS NULL);

