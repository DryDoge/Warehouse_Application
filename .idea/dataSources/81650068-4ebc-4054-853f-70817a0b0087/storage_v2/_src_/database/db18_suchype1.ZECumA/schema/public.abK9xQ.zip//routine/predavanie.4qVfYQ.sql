create function predavanie(zak integer, nap integer, skl integer, mno integer)
  returns boolean
language plpgsql
as $$
DECLARE
      mn INT;
      por INT;
    BEGIN
      mn:= (SELECT mnozstvo FROM obsahuje WHERE (idnap = nap)AND (idsklad = skl));
      por:= (SELECT MAX(idpredaj) FROM predaj);
      IF (por IS NULL) THEN por:=0;
      END IF;
      IF ((mn < mno) OR (mn IS NULL) OR (mno = 0)) THEN RETURN FALSE;
      END IF;
      por:= por +1;
      UPDATE obsahuje SET mnozstvo = mnozstvo - mno WHERE (idnap = nap)AND (idsklad = skl);
      INSERT INTO predaj VALUES (por,zak, nap, skl, mno);
      mn:= (SELECT mnozstvo FROM obsahuje WHERE (idnap = nap)AND (idsklad = skl));
      IF (mn = 0) THEN DELETE FROM obsahuje WHERE (idnap = nap)AND (idsklad = skl);
      END IF;
      RETURN TRUE;
    END;
$$;

